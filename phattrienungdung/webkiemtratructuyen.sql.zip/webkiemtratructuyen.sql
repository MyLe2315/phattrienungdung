-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2022 at 07:41 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webkiemtratructuyen`
--

-- --------------------------------------------------------

--
-- Table structure for table `baikiemtra`
--

CREATE TABLE `baikiemtra` (
  `idbaikiemtra` int(10) unsigned NOT NULL auto_increment,
  `made` int(11) NOT NULL,
  `ngayrade` date NOT NULL,
  `tieude` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `loaibaikiemtra` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `kythi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idbaikiemtra`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `baikiemtra`
--


-- --------------------------------------------------------

--
-- Table structure for table `diemvadanhgia`
--

CREATE TABLE `diemvadanhgia` (
  `iddiemso` int(10) unsigned NOT NULL auto_increment,
  `diemso` int(11) NOT NULL,
  `malop` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idbaikiemtra` int(11) NOT NULL,
  `trangthai` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`iddiemso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `diemvadanhgia`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `idgiaovien` int(10) unsigned NOT NULL auto_increment,
  `magiaovien` int(11) NOT NULL,
  `diachi` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` varchar(11) NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  PRIMARY KEY  (`idgiaovien`),
  UNIQUE KEY `magiaovien` (`magiaovien`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `giaovien`
--

INSERT INTO `giaovien` (`idgiaovien`, `magiaovien`, `diachi`, `email`, `sdt`, `hodem`, `tengiaovien`, `ngaysinh`, `idmonhoc`) VALUES
(15, 10, ' 12 Nguyễn Văn Bảo , phường 4 , Gò Vấp , HCM', 'abcxyz@gmail.com', '0123456789', 'Nguyễn Phước ', 'Lộc', '2001-10-21', 1),
(16, 14, ' 12 Nguyễn Văn Bảo , phường 4 , Gò Vấp , HCM', 'playeronl1111@gmail.com', '0984651253', 'Nguyễn Văn ', 'Minh', '2001-10-01', 3);

-- --------------------------------------------------------

--
-- Table structure for table `hocsinh`
--

CREATE TABLE `hocsinh` (
  `idhocsinh` int(10) unsigned NOT NULL auto_increment,
  `mahocsinh` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `malop` int(11) NOT NULL,
  `ngaysinh` date NOT NULL,
  `idlophoc` int(11) NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  `idkhoilop` int(11) NOT NULL,
  PRIMARY KEY  (`idhocsinh`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hocsinh`
--


-- --------------------------------------------------------

--
-- Table structure for table `khoilop`
--

CREATE TABLE `khoilop` (
  `idkhoilop` int(10) unsigned NOT NULL auto_increment,
  `makhoi` int(11) NOT NULL,
  `tenkhoi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `soluonglop` int(11) NOT NULL,
  PRIMARY KEY  (`idkhoilop`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `khoilop`
--

INSERT INTO `khoilop` (`idkhoilop`, `makhoi`, `tenkhoi`, `soluonglop`) VALUES
(1, 6, 'Khối 6', 5),
(2, 7, 'Khối 7', 5),
(3, 8, 'Khối 8', 5),
(4, 9, 'Khối 9', 5);

-- --------------------------------------------------------

--
-- Table structure for table `loaibaikiemtra`
--

CREATE TABLE `loaibaikiemtra` (
  `idloai` int(10) unsigned NOT NULL auto_increment,
  `maloai` int(11) NOT NULL,
  `tenloai` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idloai`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `loaibaikiemtra`
--


-- --------------------------------------------------------

--
-- Table structure for table `lophoc`
--

CREATE TABLE `lophoc` (
  `idlophoc` int(11) unsigned NOT NULL auto_increment,
  `malop` int(11) NOT NULL,
  `makhoi` int(11) NOT NULL,
  `tenlop` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idkhoilop` int(11) NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  PRIMARY KEY  (`idlophoc`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `lophoc`
--

INSERT INTO `lophoc` (`idlophoc`, `malop`, `makhoi`, `tenlop`, `idkhoilop`, `idmonhoc`) VALUES
(1, 61, 6, '6A1', 1, 0),
(2, 62, 6, '6A2', 1, 0),
(3, 63, 6, '6A3', 1, 0),
(4, 64, 6, '6A4', 1, 0),
(5, 65, 6, '6A5', 1, 0),
(6, 71, 7, '7A1', 2, 0),
(7, 72, 7, '7A2', 2, 0),
(8, 73, 7, '7A3', 2, 0),
(9, 74, 7, '7A4', 2, 0),
(10, 75, 7, '7A5', 2, 0),
(11, 81, 8, '8A1', 3, 0),
(12, 82, 8, '8A2', 3, 0),
(13, 83, 8, '8A3', 3, 0),
(14, 84, 8, '8A4', 3, 0),
(15, 85, 8, '8A5', 3, 0),
(16, 91, 9, '9A1', 4, 0),
(17, 92, 9, '9A2', 4, 0),
(18, 93, 9, '9A3', 4, 0),
(19, 94, 9, '9A4', 4, 0),
(20, 95, 9, '9A5', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mohoc`
--

CREATE TABLE `mohoc` (
  `idmonhoc` int(10) unsigned NOT NULL auto_increment,
  `mamon` int(11) NOT NULL,
  `tenmon` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idlophoc` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idmonhoc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mohoc`
--


-- --------------------------------------------------------

--
-- Table structure for table `nganhangcauhoi`
--

CREATE TABLE `nganhangcauhoi` (
  `idcauhoi` int(10) unsigned NOT NULL auto_increment,
  `macauhoi` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idcauhoi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nganhangcauhoi`
--


-- --------------------------------------------------------

--
-- Table structure for table `quantriviencaptruong`
--

CREATE TABLE `quantriviencaptruong` (
  `idqtvct` int(10) unsigned NOT NULL auto_increment,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `magiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idqtvct`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `quantriviencaptruong`
--


-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mataikhoan` int(11) NOT NULL,
  `matkhau` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `magiaovien` int(11) default NULL,
  `mahocsinh` int(11) default NULL,
  `tentaikhoan` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `maqtvct` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`id`, `mataikhoan`, `matkhau`, `magiaovien`, `mahocsinh`, `tentaikhoan`, `maqtvct`) VALUES
(1, 12345, 'e10adc3949ba59abbe56e057f20f883e', 12345, NULL, 'Nguyễn Văn A', NULL),
(2, 19436041, 'e10adc3949ba59abbe56e057f20f883e', NULL, 19436041, 'Lê Thị Hạnh', NULL),
(3, 19433221, 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, 'Nguyễn Phước Lộc', 19433221);

-- --------------------------------------------------------

--
-- Table structure for table `totruongchuyenmon`
--

CREATE TABLE `totruongchuyenmon` (
  `magiaovien` int(10) unsigned NOT NULL auto_increment,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `ngaysinh` date NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idcauhoi` int(11) NOT NULL,
  PRIMARY KEY  (`magiaovien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `totruongchuyenmon`
--

