-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2022 at 04:36 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webkiemtratructuyen`
--

-- --------------------------------------------------------

--
-- Table structure for table `baikiemtra`
--

CREATE TABLE `baikiemtra` (
  `idbaikiemtra` int(10) unsigned NOT NULL auto_increment,
  `made` int(11) NOT NULL,
  `ngayrade` date NOT NULL,
  `tieude` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `loaibaikiemtra` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `kythi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idbaikiemtra`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `baikiemtra`
--


-- --------------------------------------------------------

--
-- Table structure for table `diemvadanhgia`
--

CREATE TABLE `diemvadanhgia` (
  `iddiemso` int(10) unsigned NOT NULL auto_increment,
  `diemso` int(11) NOT NULL,
  `malop` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idbaikiemtra` int(11) NOT NULL,
  `trangthai` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`iddiemso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `diemvadanhgia`
--


-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `idgiaovien` int(10) unsigned NOT NULL auto_increment,
  `magiaovien` int(11) NOT NULL,
  `diachi` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  PRIMARY KEY  (`idgiaovien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giaovien`
--


-- --------------------------------------------------------

--
-- Table structure for table `hocsinh`
--

CREATE TABLE `hocsinh` (
  `idhocsinh` int(10) unsigned NOT NULL auto_increment,
  `mahocsinh` int(11) NOT NULL,
  `tenhocsinh` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `malop` int(11) NOT NULL,
  `ngaysinh` date NOT NULL,
  `idlophoc` int(11) NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  `idkhoilop` int(11) NOT NULL,
  PRIMARY KEY  (`idhocsinh`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hocsinh`
--


-- --------------------------------------------------------

--
-- Table structure for table `khoilop`
--

CREATE TABLE `khoilop` (
  `idkhoilop` int(10) unsigned NOT NULL auto_increment,
  `makhoi` int(11) NOT NULL,
  `tenkhoi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `soluonglop` int(11) NOT NULL,
  PRIMARY KEY  (`idkhoilop`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `khoilop`
--


-- --------------------------------------------------------

--
-- Table structure for table `loaibaikiemtra`
--

CREATE TABLE `loaibaikiemtra` (
  `idloai` int(10) unsigned NOT NULL auto_increment,
  `maloai` int(11) NOT NULL,
  `tenloai` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idloai`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `loaibaikiemtra`
--


-- --------------------------------------------------------

--
-- Table structure for table `lophoc`
--

CREATE TABLE `lophoc` (
  `idlophoc` int(11) unsigned NOT NULL auto_increment,
  `malop` int(11) NOT NULL,
  `makhoi` int(11) NOT NULL,
  `tenlop` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idkhoilop` int(11) NOT NULL,
  `idmonhoc` int(11) NOT NULL,
  PRIMARY KEY  (`idlophoc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lophoc`
--


-- --------------------------------------------------------

--
-- Table structure for table `mohoc`
--

CREATE TABLE `mohoc` (
  `idmonhoc` int(10) unsigned NOT NULL auto_increment,
  `mamon` int(11) NOT NULL,
  `tenmon` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idlophoc` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idmonhoc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mohoc`
--


-- --------------------------------------------------------

--
-- Table structure for table `nganhangcauhoi`
--

CREATE TABLE `nganhangcauhoi` (
  `idcauhoi` int(10) unsigned NOT NULL auto_increment,
  `macauhoi` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idcauhoi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nganhangcauhoi`
--


-- --------------------------------------------------------

--
-- Table structure for table `quantriviencaptruong`
--

CREATE TABLE `quantriviencaptruong` (
  `idqtvct` int(10) unsigned NOT NULL auto_increment,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `magiaovien` int(11) NOT NULL,
  PRIMARY KEY  (`idqtvct`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `quantriviencaptruong`
--


-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mataikhoan` int(11) NOT NULL,
  `matkhau` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `magiaovien` int(11) default NULL,
  `mahocsinh` int(11) default NULL,
  `tentaikhoan` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `maqtvct` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`id`, `mataikhoan`, `matkhau`, `magiaovien`, `mahocsinh`, `tentaikhoan`, `maqtvct`) VALUES
(1, 12345, 'e10adc3949ba59abbe56e057f20f883e', 12345, NULL, 'Nguyễn Văn A', NULL),
(2, 19436041, 'e10adc3949ba59abbe56e057f20f883e', NULL, 19436041, 'Lê Thị Hạnh', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `totruongchuyenmon`
--

CREATE TABLE `totruongchuyenmon` (
  `magiaovien` int(10) unsigned NOT NULL auto_increment,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL,
  `ngaysinh` date NOT NULL,
  `tengiaovien` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `idcauhoi` int(11) NOT NULL,
  PRIMARY KEY  (`magiaovien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `totruongchuyenmon`
--

